//
// Created by Kobe De Broeck on 19-2-2022.
//

#include "DFA.h"

#include <sstream>
#include <fstream>
#include <iostream>

#include "json.hpp"

using namespace std;
using json = nlohmann::json;

DFA::DFA(const std::string &fileName)
{
    ifstream ifs{fileName};
    if(!ifs) cerr << "Could not open DFA file\n";

    json dfaDesc;
    ifs >> dfaDesc;

    if(dfaDesc["type"] != "DFA") cerr << "File does not describe a DFA\n";

    auto states = dfaDesc["states"];
    for(auto state : states) {
        if(state["starting"]) {
            this->startState = state["name"];
        }
        if(state["accepting"]) {
            this->finalStates.insert((string)state["name"]);
        }
    }

    auto transitions = dfaDesc["transitions"];
    for(auto transition : transitions) {
        string from = transition["from"];
        string to = transition["to"];
        string input = transition["input"];
        this->transitionTable[{from, input}] = to;
    }

}

bool DFA::accepts(const std::string& s) const
{
    string currentState = startState;

    istringstream iss{s};
    for(char c; iss >> c; ) {
        currentState = transitionTable.at({currentState, string{c}});
    }

    return finalStates.find(currentState) != finalStates.end();
}
